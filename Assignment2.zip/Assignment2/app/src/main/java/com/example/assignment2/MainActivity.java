package com.example.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    public static ArrayList lat = new ArrayList<Double>();
    public static ArrayList lon = new ArrayList<Double>();
    EditText addressTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize the address search
        addressTxt = findViewById(R.id.addressSearch);

        //create database
        database db = new database(this);

        /**
         * The segment below is used when the app is first run.
         * It grabs the shared preference value called FrstTime and checks if it is false
         * This will actually return true on the very first run of the oncreate method, hence the ! inverter on the if statement
         * It reads the CSV file of the Lat and Long of Ontario Court houses obtained here:
         *
         * https://open.canada.ca/data/en/dataset/849b516b-e355-48e9-89f0-9190598814c9?wbdisable=true
         *
         */
        SharedPreferences ratePrefs = getSharedPreferences("First Update", 0);
        if (!ratePrefs.getBoolean("FrstTime", false)) {

            //Get the CSV file from the Value->Raw directory
            InputStream inputStream = getResources().openRawResource(R.raw.lat_long);

            //create new CSV file reader and read it
            CSVFile csvFile = new CSVFile(inputStream);
            csvFile.read();

            //create Geocoder and address list
            Geocoder geocoder;
            List<Address> addresses = null;
            geocoder = new Geocoder(this, Locale.getDefault());
            //loop through the list of lat and longs and parse them through the GeoCoder
            for (int i = 0; i < lat.size(); i++) {
                try {
                    addresses = geocoder.getFromLocation((double) lat.get(i), (double) lon.get(i), 1);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                //add the address, lat and long to the database
                db.add(addresses.get(0).getAddressLine(0), (double) lat.get(i), (double) lon.get(i));
            }
            //Set the FrstTime Variable to true so this will not run again
            SharedPreferences.Editor edit = ratePrefs.edit();
            edit.putBoolean("FrstTime", true);
            edit.commit();
        }


        //Initialize the view all button
        Button viewAll = findViewById(R.id.viewButton);
        viewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                //Navigate to the view all activity
                Intent createNoteActivity = new Intent(MainActivity.this, ViewAll.class);
                MainActivity.this.startActivity(createNoteActivity);
            }
        });
        //Initialize search button
        Button query = findViewById(R.id.searchButton);
        query.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                //Create the intent to move to the view results page, add the address to the intent as an extra
                //Create the intent to move to the view results page, add the address to the intent as an extra
                Intent intent = new Intent(MainActivity.this, view_query.class);
                intent.putExtra("address",addressTxt.getText().toString());
                MainActivity.this.startActivity(intent);
            }
        });


    }
}

class CSVFile {
    InputStream inputStream;

    public CSVFile(InputStream inputStream){
        this.inputStream = inputStream;
    }

    public void read(){
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        try {
            String csvLine;
            while ((csvLine = reader.readLine()) != null) {
                String[] row = csvLine.split(",");
                MainActivity.lat.add(Double.parseDouble(row[0]));
                MainActivity.lon.add(Double.parseDouble(row[1]));
            }
        }
        catch (IOException ex) {
            throw new RuntimeException("Error in reading CSV file: "+ex);
        }
        finally {
            try {
                inputStream.close();
            }
            catch (IOException e) {
                throw new RuntimeException("Error while closing input stream: "+e);
            }
        }
    }
}