package com.example.assignment2;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class addLocation extends AppCompatActivity {
    EditText lat, lon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_location);

        //Initialize the edit text boxes
        lat = findViewById(R.id.latAdd);
        lon = findViewById(R.id.lonAdd);

        //Set actionbar title and home button
        ActionBar ab = getSupportActionBar();
        if (ab != null) {
            ab.setTitle("Adding Address");
            ab.setDisplayHomeAsUpEnabled(true);
        }

        //Declare an alert box to be used in the error handling of null inputs
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        //Add backout button onto the alert box that closes the alert box upon "ok" being pressed
        alert.setNegativeButton(
                "Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        //Create intent to go back to the ViewLocations Page
        Intent backToLocations = new Intent(addLocation.this, ViewAll.class);

        // Cancel button returns to previous page via intent
        Button cancel = findViewById(R.id.cancel_btn);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                addLocation.this.startActivity(backToLocations);
            }
        });

        // Save button
        Button save = findViewById(R.id.save_btn);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Check if the Latitude or Longitude are empty or within the bounds require for Lat and Long
                if(TextUtils.isEmpty(lat.getText().toString()))
                {
                    //Tell the user that the mortgage is not set correctly
                    alert.setMessage("Latitude is not set.");
                    alert.setCancelable(true);
                    alert.show();
                }
                else if(TextUtils.isEmpty(lon.getText().toString()))
                {
                    //Tell the user that the mortgage is not set correctly
                    alert.setMessage("Longitude is not set.");
                    alert.setCancelable(true);
                    alert.show();
                }
                else {
                    Double latitude = Double.parseDouble(lat.getText().toString());
                    Double longitude = Double.parseDouble(lon.getText().toString());
                    if(latitude>90 || latitude <-90)
                    {
                        //Tell the user that the mortgage is not set correctly
                        alert.setMessage("Latitude must be between -90 and 90.");
                        alert.setCancelable(true);
                        alert.show();
                    }
                    else if(longitude>180 || longitude <-180)
                    {
                        //Tell the user that the mortgage is not set correctly
                        alert.setMessage("Longitude must be between -180 and 180.");
                        alert.setCancelable(true);
                        alert.show();
                    }
                    else
                    {
                        //If the Lat and Long are valid, use the Geocoder to grab the address of the Lat and Long
                        Geocoder geocoder;
                        List<Address> addresses = null;
                        geocoder = new Geocoder(addLocation.this, Locale.getDefault());
                        database db = new database(addLocation.this);
                        try {
                            addresses = geocoder.getFromLocation(latitude, longitude, 1);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        //add the address, lat and long to the database, use the intent to return to the main area
                        db.add(addresses.get(0).getAddressLine(0), latitude, longitude);
                        addLocation.this.startActivity(backToLocations);
                    }
                }
            }
        });

    }
}